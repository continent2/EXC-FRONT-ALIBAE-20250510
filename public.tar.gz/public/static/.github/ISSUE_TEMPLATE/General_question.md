---
name: General Question
about: Ask a question if you cannot find an answer in the documentation
title: ''
labels: status/conversation
assignees: ''

---

# General Question

<!-- PLEASE MAKE SURE THAT YOU HAVE READ FAQ -->
<!-- https://github.com/tradingview/charting_library/wiki/Frequently-Asked-Questions -->

- [ ] I have read FAQ <!-- replace the space in the brackets with `x` -->

**Ask your question with the greatest possible detail**

<!-- Write your question right here...  -->
